package com.csvfile;

import com.csvfile.models.InputRecord;
import com.csvfile.models.ReferenceRecord;
import com.csvfile.models.OutputRecord;
import com.csvfile.services.TransformationService;
import com.csvfile.services.FileProcessingService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class FileProcessingServiceTest {

    @Test
    public void testTransform() {
        TransformationService transformationService = new TransformationService();

        InputRecord input = new InputRecord();
        input.setField1("A");
        input.setField2("B");
        input.setField3("C");
        input.setField5(new BigDecimal("10"));
        input.setRefkey1("key1");
        input.setRefkey2("key2");

        ReferenceRecord reference = new ReferenceRecord();
        reference.setRefkey1("key1");
        reference.setRefdata1("R1");
        reference.setRefkey2("key2");
        reference.setRefdata2("R2");
        reference.setRefdata3("R3");
        reference.setRefdata4(new BigDecimal("15"));

        OutputRecord expectedOutput = new OutputRecord();
        expectedOutput.setOutfield1("AB");
        expectedOutput.setOutfield2("R1");
        expectedOutput.setOutfield3("R2R3");
        expectedOutput.setOutfield4(new BigDecimal("15"));
        expectedOutput.setOutfield5(new BigDecimal("15"));

        OutputRecord actualOutput = transformationService.transform(input, reference);

        assertEquals(expectedOutput, actualOutput);
    }

    @Test
    public void testProcessFiles() throws IOException {
        TransformationService transformationService = Mockito.mock(TransformationService.class);
        FileProcessingService fileProcessingService = new FileProcessingService();
//        fileProcessingService.setTransformationService(transformationService);

        InputRecord input = new InputRecord();
        input.setField1("A");
        input.setField2("B");
        input.setField3("C");
        input.setField5(new BigDecimal("10"));
        input.setRefkey1("key1");
        input.setRefkey2("key2");

        ReferenceRecord reference = new ReferenceRecord();
        reference.setRefkey1("key1");
        reference.setRefdata1("R1");
        reference.setRefkey2("key2");
        reference.setRefdata2("R2");
        reference.setRefdata3("R3");
        reference.setRefdata4(new BigDecimal("15"));

        OutputRecord output = new OutputRecord();
        output.setOutfield1("AB");
        output.setOutfield2("R1");
        output.setOutfield3("R2R3");
        output.setOutfield4(new BigDecimal("15"));
        output.setOutfield5(new BigDecimal("15"));

        Mockito.when(transformationService.transform(input, reference)).thenReturn(output);

        List<InputRecord> inputRecords = Arrays.asList(input);
        List<ReferenceRecord> referenceRecords = Arrays.asList(reference);

        fileProcessingService.processFiles("inputFilePath", "referenceFilePath", "outputFilePath");

        Mockito.verify(transformationService, Mockito.times(1)).transform(input, reference);
    }
}
