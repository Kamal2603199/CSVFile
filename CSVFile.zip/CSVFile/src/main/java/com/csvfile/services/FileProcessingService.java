package com.csvfile.services;

import com.csvfile.models.InputRecord;
import com.csvfile.models.OutputRecord;
import com.csvfile.models.ReferenceRecord;
import com.csvfile.utils.CSVUtils;
import com.opencsv.bean.CsvToBeanBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.FileReader;
import java.io.IOException;
import java.util.List;

@Service
public class FileProcessingService {

    @Autowired
    private TransformationService transformationService;

    public void processFiles(String inputFilePath, String referenceFilePath, String outputFilePath) throws IOException {
        List<InputRecord> inputRecords = new CsvToBeanBuilder<InputRecord>(new FileReader(inputFilePath))
                .withType(InputRecord.class)
                .build()
                .parse();

        List<ReferenceRecord> referenceRecords = new CsvToBeanBuilder<ReferenceRecord>(new FileReader(referenceFilePath))
                .withType(ReferenceRecord.class)
                .build()
                .parse();

        List<OutputRecord> outputRecords = inputRecords.stream()
                .map(input -> {
                    ReferenceRecord reference = findReference(referenceRecords, input);
                    return transformationService.transform(input, reference);
                })
                .toList();

        CSVUtils.writeToCSV(outputRecords, outputFilePath);
    }

    private ReferenceRecord findReference(List<ReferenceRecord> referenceRecords, InputRecord input) {
        return referenceRecords.stream()
                .filter(ref -> ref.getRefkey1().equals(input.getRefkey1()) && ref.getRefkey2().equals(input.getRefkey2()))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Reference data not found"));
    }
}
