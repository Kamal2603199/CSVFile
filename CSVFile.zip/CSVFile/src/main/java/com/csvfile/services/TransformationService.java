package com.csvfile.services;

import com.csvfile.models.InputRecord;
import com.csvfile.models.OutputRecord;
import com.csvfile.models.ReferenceRecord;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class TransformationService {

    public OutputRecord transform(InputRecord input, ReferenceRecord reference) {
        OutputRecord output = new OutputRecord();
        output.setOutfield1(input.getField1() + input.getField2());
        output.setOutfield2(reference.getRefdata1());
        output.setOutfield3(reference.getRefdata2() + reference.getRefdata3());
        output.setOutfield4(input.getField5().max(reference.getRefdata4()));
        output.setOutfield5(input.getField5().max(reference.getRefdata4()));
        return output;
    }
}