package com.csvfile.utils;

import com.csvfile.models.OutputRecord;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import com.opencsv.exceptions.CsvException;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class CSVUtils {

    public static void writeToCSV(List<OutputRecord> outputRecords, String outputFilePath) throws IOException {
        try (FileWriter writer = new FileWriter(outputFilePath)) {
            StatefulBeanToCsv<OutputRecord> beanToCsv = new StatefulBeanToCsvBuilder<OutputRecord>(writer)
                    .build();
            beanToCsv.write(outputRecords);
        } catch (CsvException e) {
            throw new RuntimeException("Error writing CSV file", e);
        }
    }
}
