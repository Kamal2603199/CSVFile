package com.csvfile.controllers;
import com.csvfile.services.FileProcessingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

@RestController
public class ReportController {

    @Autowired
    private FileProcessingService fileProcessingService;

    @PostMapping("/generate-report")
    public String generateReport(@RequestParam String inputFilePath, 
                                 @RequestParam String referenceFilePath, 
                                 @RequestParam String outputFilePath) {
        try {
            fileProcessingService.processFiles(inputFilePath, referenceFilePath, outputFilePath);
            return "Report generated successfully";
        } catch (IOException e) {
            return "Error generating report: " + e.getMessage();
        }
    }
}
