package com.csvfile.config;

import com.csvfile.services.FileProcessingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class ScheduledTasks {

    @Autowired
    private FileProcessingService fileProcessingService;

    @Scheduled(cron = "0 0 0 * * ?")
    public void generateReport() {
        try {
            String inputFilePath = "path/to/input.csv";
            String referenceFilePath = "path/to/reference.csv";
            String outputFilePath = "path/to/output.csv";
            fileProcessingService.processFiles(inputFilePath, referenceFilePath, outputFilePath);
        } catch (IOException e) {
            // Log error
        }
    }
}
